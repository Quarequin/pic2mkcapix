// Auto-concatenated from comp — do not edit; edit modules then run node comp/concat.mjs

/* ==== core/quantize.c ==== */
/*
 * pic2mkcapix — core quantize (ordered dither + Floyd–Steinberg + nearest).
 * Concat order into comp.c: core/quantize.c then main.c
 */
#include <stdint.h>

/*
 * comp_process returns a byte-sized status code; 0 means success.
 * The host must place every buffer at or above comp_heap_base(): the area
 * below it holds the static Bayer/Blue Noise tables and the C stack.
 */
enum {
	COMP_OK = 0,
	COMP_INVALID_ARGUMENT = 1,
	COMP_MISSING_ERROR_BUFFER = 2,
	COMP_MEMORY_RANGE = 3,
	COMP_UNSUPPORTED_MODE = 4,
	COMP_DIMENSION_OVERFLOW = 5,
	COMP_ERROR_CODE_MAX = 255,
};

void *memset(void *destination, int value, __SIZE_TYPE__ count) {
	uint8_t *bytes = (uint8_t *)destination;
	for (__SIZE_TYPE__ index = 0; index < count; ++index) bytes[index] = (uint8_t)value;
	return destination;
}

static const uint16_t BAYER4_SRC[16] = {
	0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5,
};

static const uint16_t BAYER8_SRC[64] = {
	0, 32, 8, 40, 2, 34, 10, 42, 48, 16, 56, 24, 50, 18, 58, 26,
	12, 44, 4, 36, 14, 46, 6, 38, 60, 28, 52, 20, 62, 30, 54, 22,
	3, 35, 11, 43, 1, 33, 9, 41, 51, 19, 59, 27, 49, 17, 57, 25,
	15, 47, 7, 39, 13, 45, 5, 37, 63, 31, 55, 23, 61, 29, 53, 21,
};

static const uint16_t BAYER16_SRC[256] = {
	0, 128, 32, 160, 8, 136, 40, 168, 2, 130, 34, 162, 10, 138, 42, 170,
	192, 64, 224, 96, 200, 72, 232, 104, 194, 66, 226, 98, 202, 74, 234, 106,
	48, 176, 16, 144, 56, 184, 24, 152, 50, 178, 18, 146, 58, 186, 26, 154,
	240, 112, 208, 80, 248, 120, 216, 88, 242, 114, 210, 82, 250, 122, 218, 90,
	12, 140, 44, 172, 4, 132, 36, 164, 14, 142, 46, 174, 6, 134, 38, 166,
	204, 76, 236, 108, 196, 68, 228, 100, 206, 78, 238, 110, 198, 70, 230, 102,
	60, 188, 28, 156, 52, 180, 20, 148, 62, 190, 30, 158, 54, 182, 22, 150,
	252, 124, 220, 92, 244, 116, 212, 84, 254, 126, 222, 94, 246, 118, 214, 86,
	3, 131, 35, 163, 11, 139, 43, 171, 1, 129, 33, 161, 9, 137, 41, 169,
	195, 67, 227, 99, 203, 75, 235, 107, 193, 65, 225, 97, 201, 73, 233, 105,
	51, 179, 19, 147, 59, 187, 27, 155, 49, 177, 17, 145, 57, 185, 25, 153,
	243, 115, 211, 83, 251, 123, 219, 91, 241, 113, 209, 81, 249, 121, 217, 89,
	15, 143, 47, 175, 7, 135, 39, 167, 13, 141, 45, 173, 5, 133, 37, 165,
	207, 79, 239, 111, 199, 71, 231, 103, 205, 77, 237, 109, 197, 69, 229, 101,
	63, 191, 31, 159, 55, 183, 23, 151, 61, 189, 29, 157, 53, 181, 21, 149,
	255, 127, 223, 95, 247, 119, 215, 87, 253, 125, 221, 93, 245, 117, 213, 85,
};

static const uint16_t BLUE8_SRC[64] = {
	141, 186, 149, 52, 101, 182, 137, 105, 170, 113, 206, 20, 242, 153, 202, 246,
	64, 222, 80, 32, 117, 12, 89, 40, 16, 48, 161, 210, 178, 60, 24, 0,
	230, 93, 250, 145, 72, 234, 190, 109, 56, 4, 121, 198, 157, 125, 36, 214,
	68, 8, 44, 174, 133, 255, 85, 28, 226, 97, 238, 76, 218, 129, 194, 165,
};

static const uint16_t BLUE16_SRC[256] = {
	227, 141, 129, 236, 160, 134, 71, 30, 162, 235, 99, 209, 108, 192, 94, 155,
	78, 190, 153, 53, 86, 224, 178, 148, 93, 42, 183, 144, 26, 73, 10, 41,
	139, 3, 248, 115, 200, 13, 63, 249, 170, 126, 213, 56, 166, 232, 118, 204,
	59, 220, 172, 112, 33, 154, 245, 88, 195, 14, 48, 104, 185, 6, 150, 80,
	131, 241, 96, 21, 180, 70, 137, 22, 237, 84, 38, 202, 1, 67, 222, 122,
	252, 46, 164, 128, 255, 107, 52, 191, 143, 218, 11, 158, 91, 176, 40, 207,
	17, 110, 74, 233, 45, 198, 25, 120, 60, 247, 101, 29, 134, 50, 240, 168,
	82, 197, 5, 187, 159, 77, 212, 35, 173, 8, 114, 69, 226, 147, 19, 94,
	234, 136, 58, 181, 14, 92, 250, 44, 211, 132, 54, 193, 12, 86, 223, 105,
	49, 171, 109, 28, 243, 125, 68, 156, 4, 182, 97, 36, 254, 151, 64, 216,
	189, 31, 238, 83, 167, 47, 206, 116, 244, 17, 146, 79, 199, 42, 117, 230,
	2, 161, 100, 19, 140, 221, 57, 185, 102, 72, 215, 10, 127, 253, 89, 178,
	75, 208, 43, 251, 111, 6, 163, 34, 188, 129, 61, 239, 24, 165, 55, 196,
	145, 27, 124, 95, 230, 152, 81, 246, 15, 113, 48, 175, 204, 37, 142, 9,
	219, 66, 194, 18, 76, 135, 23, 106, 231, 51, 183, 7, 121, 247, 103, 214,
	62, 169, 0, 149, 210, 87, 201, 39, 168, 98, 33, 158, 20, 228, 141, 184,
};

static const uint16_t BLUE32_SRC[1024] = {
	154, 181, 42, 20, 79, 34, 109, 18, 95, 135, 190, 84, 202, 128, 190, 68,
	34, 1, 23, 84, 237, 70, 225, 144, 237, 165, 49, 102, 237, 109, 186, 70,
	9, 116, 220, 248, 163, 253, 147, 212, 55, 245, 14, 167, 38, 57, 11, 233,
	152, 197, 139, 174, 54, 122, 14, 92, 63, 13, 197, 180, 26, 142, 59, 217,
	131, 204, 88, 52, 137, 101, 28, 194, 230, 119, 176, 244, 96, 214, 156, 46,
	111, 81, 219, 32, 241, 160, 206, 132, 227, 120, 251, 89, 194, 5, 103, 168,
	36, 173, 15, 229, 64, 185, 239, 73, 4, 50, 21, 126, 35, 78, 191, 138,
	28, 149, 64, 113, 17, 72, 38, 177, 48, 155, 33, 67, 218, 161, 78, 21,
	243, 105, 199, 58, 222, 12, 158, 91, 169, 201, 143, 59, 249, 17, 106, 223,
	182, 95, 236, 6, 151, 100, 211, 10, 83, 201, 123, 242, 12, 133, 230, 47,
	80, 41, 250, 124, 39, 171, 48, 134, 255, 110, 82, 188, 40, 129, 71, 195,
	53, 164, 20, 127, 189, 44, 136, 254, 29, 172, 52, 107, 187, 94, 25, 209,
	216, 145, 27, 183, 96, 235, 77, 19, 61, 226, 151, 8, 166, 93, 247, 31,
	115, 75, 198, 58, 232, 81, 19, 117, 223, 41, 158, 76, 255, 57, 150, 114,
	62, 232, 112, 7, 213, 53, 141, 203, 125, 37, 104, 197, 49, 179, 13, 85,
	240, 46, 130, 243, 15, 169, 62, 146, 96, 181, 8, 199, 35, 126, 205, 88,
	175, 2, 193, 66, 156, 30, 102, 247, 86, 173, 21, 68, 157, 221, 108, 194,
	60, 153, 11, 87, 184, 128, 236, 51, 134, 220, 69, 148, 242, 16, 44, 179,
	118, 229, 47, 139, 11, 224, 67, 181, 42, 250, 145, 33, 84, 6, 238, 74,
	165, 101, 217, 43, 99, 24, 163, 79, 11, 252, 106, 31, 171, 83, 197, 121,
	54, 161, 100, 255, 74, 189, 116, 5, 159, 97, 54, 210, 127, 45, 161, 29,
	212, 56, 140, 191, 70, 208, 45, 190, 147, 60, 183, 224, 55, 140, 10, 236,
	207, 23, 132, 81, 214, 46, 152, 231, 19, 136, 77, 186, 253, 118, 203, 52,
	34, 123, 226, 5, 155, 37, 114, 234, 28, 95, 215, 40, 129, 249, 72, 165,
	38, 187, 14, 172, 60, 129, 245, 108, 63, 204, 28, 92, 144, 67, 12, 176,
	247, 91, 48, 170, 102, 250, 84, 6, 173, 131, 51, 199, 22, 104, 188, 53,
	143, 68, 228, 93, 201, 38, 17, 78, 168, 113, 242, 56, 185, 230, 89, 41,
	158, 22, 135, 59, 218, 141, 193, 122, 57, 246, 110, 80, 154, 37, 231, 98,
	251, 122, 49, 195, 8, 166, 220, 44, 137, 2, 75, 149, 23, 105, 254, 147,
	78, 204, 33, 116, 63, 180, 29, 159, 100, 21, 164, 235, 48, 213, 117, 7,
	16, 177, 106, 34, 157, 85, 54, 192, 117, 234, 43, 162, 198, 61, 128, 19,
	187, 49, 225, 94, 213, 46, 126, 205, 73, 145, 30, 112, 191, 62, 136, 219,
	182, 65, 240, 13, 111, 203, 26, 91, 14, 179, 101, 38, 81, 172, 56, 221,
	14, 168, 77, 151, 35, 108, 244, 17, 156, 88, 207, 42, 125, 254, 20, 96,
	44, 209, 124, 50, 173, 7, 148, 63, 246, 120, 53, 209, 28, 143, 95, 34,
	192, 115, 58, 230, 12, 185, 71, 138, 50, 241, 169, 28, 181, 74, 159, 46,
	233, 28, 158, 86, 197, 36, 225, 131, 72, 19, 160, 247, 110, 64, 187, 252,
	106, 44, 199, 82, 167, 54, 219, 97, 10, 196, 121, 64, 233, 8, 143, 111,
	102, 55, 236, 19, 141, 250, 94, 43, 188, 83, 230, 15, 76, 155, 42, 128,
	73, 161, 27, 113, 237, 129, 32, 176, 85, 218, 47, 153, 102, 194, 57, 248,
	167, 78, 217, 60, 32, 115, 177, 57, 204, 134, 48, 171, 222, 9, 198, 61,
	214, 136, 93, 181, 20, 63, 150, 242, 38, 127, 255, 70, 137, 29, 226, 84,
	13, 194, 110, 147, 229, 68, 21, 165, 100, 38, 116, 195, 52, 140, 24, 83,
	47, 172, 38, 248, 105, 200, 89, 25, 174, 58, 211, 95, 19, 166, 51, 123,
	145, 42, 255, 92, 5, 183, 109, 237, 79, 155, 253, 69, 163, 237, 117, 45,
	156, 29, 119, 68, 214, 48, 133, 61, 222, 145, 35, 189, 245, 108, 200, 75,
	35, 172, 79, 21, 161, 54, 128, 46, 214, 12, 88, 146, 31, 102, 189, 254,
	97, 184, 52, 227, 11, 163, 78, 236, 103, 30, 152, 81, 17, 132, 62, 238,
	204, 118, 53, 198, 113, 244, 33, 191, 152, 67, 180, 41, 207, 74, 136, 21,
	60, 141, 249, 16, 94, 128, 44, 191, 56, 220, 128, 194, 90, 247, 43, 156,
	11, 230, 141, 37, 86, 18, 156, 96, 25, 123, 201, 58, 149, 232, 57, 166,
	205, 79, 34, 117, 173, 55, 210, 123, 167, 12, 71, 185, 54, 116, 203, 31,
	99, 64, 189, 246, 169, 76, 210, 139, 222, 49, 85, 173, 40, 115, 253, 88,
	46, 151, 223, 62, 139, 2, 80, 158, 229, 97, 146, 38, 219, 177, 9, 68,
	152, 25, 107, 14, 58, 193, 45, 235, 162, 106, 37, 154, 245, 18, 131, 72,
	186, 101, 54, 193, 28, 115, 237, 49, 126, 213, 65, 251, 133, 40, 95, 182,
	219, 82, 175, 128, 231, 3, 120, 71, 14, 199, 126, 61, 96, 179, 43, 210,
	129, 17, 164, 88, 206, 70, 152, 34, 181, 57, 112, 29, 158, 224, 77, 144,
	48, 201, 40, 91, 165, 134, 51, 187, 250, 92, 144, 28, 68, 151, 234, 57,
	242, 125, 73, 195, 42, 129, 223, 91, 20, 138, 246, 84, 191, 53, 121, 0,
	116, 56, 213, 30, 149, 80, 205, 110, 53, 168, 35, 113, 202, 84, 19, 160,
	103, 48, 212, 36, 154, 247, 66, 175, 108, 32, 170, 63, 235, 147, 26, 198,
	67, 180, 12, 241, 104, 226, 63, 19, 143, 218, 76, 183, 47, 132, 251, 95,
	38, 171, 59, 140, 218, 101, 45, 133, 241, 155, 87, 199, 44, 110, 179, 250,
};

static uint8_t clamp_byte(int value) {
	return (uint8_t)(value < 0 ? 0 : value > 255 ? 255 : value);
}

/* Redmean perceptual distance (matches JS colorDistanceSq / Compuphase). */
static uint32_t nearest_palette(const uint8_t *palette, uint32_t count, int r, int g, int b) {
	uint32_t best = 0;
	uint32_t best_distance = 0xffffffffU;
	for (uint32_t index = 0; index < count; ++index) {
		const uint8_t *color = palette + index * 4U;
		if (color[3] < 128U) continue;
		const int rmean = (r + (int)color[0]) >> 1;
		const int dr = r - (int)color[0];
		const int dg = g - (int)color[1];
		const int db = b - (int)color[2];
		const uint32_t distance = (uint32_t)(
			(((512 + rmean) * dr * dr) >> 8) + 4 * dg * dg + (((767 - rmean) * db * db) >> 8));
		if (distance < best_distance) {
			best_distance = distance;
			best = index;
		}
	}
	return best;
}

static void add_error(int32_t *errors, uint32_t index, int value, uint32_t weight) {
	errors[index] += (value * (int)weight) / 16;
}

/* Host-provided blue-noise maps for modes 8/9/10 (64/128/256). */
static const uint8_t *host_blue_matrix = 0;
static uint32_t host_blue_size = 0;

/* Centered ordered-dither threshold aligned with WebGL:
 *   factor = value / levels - 0.5
 *   delta  = factor * amplitude
 * Bayer levels are n² (16/64/256), not (n²-1).
 * Modes 8–10 read an 8-bit matrix the host copied into linear memory.
 */
static int ordered_delta(uint32_t mode, uint32_t x, uint32_t y) {
	uint32_t size = 0, levels = 0;
	int amplitude = 0;
	uint32_t value = 0;
	switch (mode) {
		case 1: {
			size = 4; levels = 16; amplitude = 136;
			value = BAYER4_SRC[(y % size) * size + (x % size)];
			break;
		}
		case 2: {
			size = 8; levels = 64; amplitude = 152;
			value = BAYER8_SRC[(y % size) * size + (x % size)];
			break;
		}
		case 3: {
			size = 16; levels = 256; amplitude = 168;
			value = BAYER16_SRC[(y % size) * size + (x % size)];
			break;
		}
		case 4: {
			size = 8; levels = 256; amplitude = 136;
			value = BLUE8_SRC[(y % size) * size + (x % size)];
			break;
		}
		case 5: {
			size = 16; levels = 256; amplitude = 152;
			value = BLUE16_SRC[(y % size) * size + (x % size)];
			break;
		}
		case 6: {
			size = 32; levels = 256; amplitude = 168;
			value = BLUE32_SRC[(y % size) * size + (x % size)];
			break;
		}
		case 8: case 9: case 10: {
			if (!host_blue_matrix || !host_blue_size) return 0;
			size = host_blue_size;
			levels = 256;
			amplitude = mode == 8 ? 176 : mode == 9 ? 184 : 192;
			value = host_blue_matrix[(y % size) * size + (x % size)];
			break;
		}
		default: return 0;
	}
	/* (value / levels - 0.5) * amplitude  in integer math */
	return (int)((amplitude * value) / levels) - (amplitude / 2);
}

extern unsigned char __heap_base;

/* First byte the host may use; static data and the stack end below it. */
uint32_t comp_heap_base(void) {
	return (uint32_t)(uintptr_t)&__heap_base;
}

/* mode: 0 solid, 1-3 Bayer, 4-6 Blue 8/16/32, 7 Floyd, 8-10 Blue 64/128/256 (host matrix via error_ptr). */
uint32_t comp_process(uint32_t src_ptr, uint32_t palette_ptr, uint32_t out_ptr,
	uint32_t width, uint32_t height, uint32_t palette_count, uint32_t mode,
	uint32_t error_ptr, uint32_t memory_bytes) {
	if (!src_ptr || !palette_ptr || !out_ptr || !width || !height || !palette_count || palette_count > 65536U)
		return COMP_INVALID_ARGUMENT;
	const uint64_t source_bytes = (uint64_t)width * height * 4U;
	const uint64_t output_bytes = (uint64_t)width * height * 2U;
	const uint64_t error_bytes = (uint64_t)width * 3U * 2U * sizeof(int32_t);
	if (source_bytes > 0xffffffffULL || output_bytes > 0xffffffffULL || error_bytes > 0xffffffffULL)
		return COMP_DIMENSION_OVERFLOW;
	if (mode > 10U)
		return COMP_UNSUPPORTED_MODE;
	host_blue_matrix = 0;
	host_blue_size = 0;
	if (mode >= 8U && mode <= 10U) {
		host_blue_size = mode == 8U ? 64U : mode == 9U ? 128U : 256U;
		if (!error_ptr) return COMP_MISSING_ERROR_BUFFER;
		if ((uint64_t)error_ptr + (uint64_t)host_blue_size * host_blue_size > memory_bytes)
			return COMP_MEMORY_RANGE;
		host_blue_matrix = (const uint8_t *)(uintptr_t)error_ptr;
	}
	if ((uint64_t)src_ptr + source_bytes > memory_bytes ||
		(uint64_t)palette_ptr + (uint64_t)palette_count * 4U > memory_bytes ||
		(uint64_t)out_ptr + output_bytes > memory_bytes ||
		(mode == 7U && ((uint64_t)error_ptr + error_bytes > memory_bytes)))
		return COMP_MEMORY_RANGE;
	const uint8_t *src = (const uint8_t *)(uintptr_t)src_ptr;
	const uint8_t *palette = (const uint8_t *)(uintptr_t)palette_ptr;
	uint16_t *out = (uint16_t *)(uintptr_t)out_ptr;
	int32_t *errors = (int32_t *)(uintptr_t)error_ptr;
	const uint32_t row_bytes = width * 3U;
	if (mode == 7U && !error_ptr) return COMP_MISSING_ERROR_BUFFER;
	if (mode == 7U) for (uint32_t i = 0; i < row_bytes * 2U; ++i) errors[i] = 0;
	for (uint32_t y = 0; y < height; ++y) {
		int32_t *current = errors + ((y & 1U) * row_bytes);
		int32_t *next = errors + (((y + 1U) & 1U) * row_bytes);
		if (mode == 7U) for (uint32_t i = 0; i < row_bytes; ++i) next[i] = 0;
		/* Ordered modes: left→right residual carry (matches Script/GPU 0.85). */
		int residual_r = 0, residual_g = 0, residual_b = 0;
		/* Floyd–Steinberg (mode 7): serpentine — odd rows right→left. */
		const int left_to_right = (mode != 7U) || ((y & 1U) == 0U);
		const int32_t x_start = left_to_right ? 0 : (int32_t)width - 1;
		const int32_t x_end = left_to_right ? (int32_t)width : -1;
		const int32_t x_step = left_to_right ? 1 : -1;
		for (int32_t xi = x_start; xi != x_end; xi += x_step) {
			const uint32_t x = (uint32_t)xi;
			const uint32_t pixel = y * width + x;
			const uint8_t *rgba = src + pixel * 4U;
			if (rgba[3] < 128U) {
				out[pixel] = 0;
				residual_r = residual_g = residual_b = 0;
				continue;
			}
			int r = rgba[0], g = rgba[1], b = rgba[2];
			if ((mode >= 1U && mode <= 6U) || (mode >= 8U && mode <= 10U)) {
				const int delta = ordered_delta(mode, x, y);
				r = clamp_byte(r + residual_r + delta);
				g = clamp_byte(g + residual_g + delta);
				b = clamp_byte(b + residual_b + delta);
			} else if (mode == 7U) {
				const uint32_t offset = x * 3U;
				r = clamp_byte(r + current[offset]);
				g = clamp_byte(g + current[offset + 1U]);
				b = clamp_byte(b + current[offset + 2U]);
			}
			const uint32_t selected = nearest_palette(palette, palette_count, r, g, b);
			out[pixel] = (uint16_t)selected;
			if ((mode >= 1U && mode <= 6U) || (mode >= 8U && mode <= 10U)) {
				const uint8_t *color = palette + selected * 4U;
				/* 0.85 residual ≈ 17/20 — keep more error for true-colour average */
				residual_r = ((r - (int)color[0]) * 17) / 20;
				residual_g = ((g - (int)color[1]) * 17) / 20;
				residual_b = ((b - (int)color[2]) * 17) / 20;
			} else if (mode == 7U) {
				const uint8_t *color = palette + selected * 4U;
				const int er = r - color[0], eg = g - color[1], eb = b - color[2];
				const uint32_t offset = x * 3U;
				const int32_t ahead = left_to_right ? 1 : -1;
				const int32_t xa = (int32_t)x + ahead;
				const int32_t xb = (int32_t)x - ahead;
				if (xa >= 0 && xa < (int32_t)width) {
					const uint32_t ao = (uint32_t)xa * 3U;
					add_error(current, ao, er, 7);
					add_error(current, ao + 1U, eg, 7);
					add_error(current, ao + 2U, eb, 7);
				}
				if (y + 1U < height) {
					if (xb >= 0 && xb < (int32_t)width) {
						const uint32_t bo = (uint32_t)xb * 3U;
						add_error(next, bo, er, 3);
						add_error(next, bo + 1U, eg, 3);
						add_error(next, bo + 2U, eb, 3);
					}
					add_error(next, offset, er, 5);
					add_error(next, offset + 1U, eg, 5);
					add_error(next, offset + 2U, eb, 5);
					if (xa >= 0 && xa < (int32_t)width) {
						const uint32_t ao = (uint32_t)xa * 3U;
						add_error(next, ao, er, 1);
						add_error(next, ao + 1U, eg, 1);
						add_error(next, ao + 2U, eb, 1);
					}
				}
			}
		}
	}
	return COMP_OK;
}

/* ==== main.c ==== */
/**
 * pic2mkcapix WASM quantizer — modular entry
 *
 * Source order (concat → comp.c):
 *   1. core/quantize.c
 *   2. main.c
 *
 * Build the concatenated unit (from repo root):
 *   node comp/concat.mjs
 *   clang --target=wasm32 -O3 -nostdlib \
 *     -Wl,--no-entry \
 *     -Wl,--export=comp_process \
 *     -Wl,--export=comp_heap_base \
 *     -Wl,--export=memory \
 *     -o comp/comp.wasm \
 *     comp/comp.c
 *
 * Exports (implemented in core/quantize.c):
 *   memory, comp_process, comp_heap_base
 */
